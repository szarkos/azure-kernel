// SPDX-License-Identifier: GPL-2.0

#include "hyperv_vmbus.h"

#define CREATE_TRACE_POINTS
#include "hv_trace.h"
